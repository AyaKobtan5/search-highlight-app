import React, { useState } from "react";

const ArticleSearch = ({ articles }) => {
  const [searchInput, setSearchInput] = useState("");

  const highlightMatch = (text) => {
    if (!searchInput) return text;
    const regex = new RegExp(`(${searchInput})`, "gi");
    return text.split(regex).map((piece, i) =>
      regex.test(piece) ? <mark key={i}>{piece}</mark> : piece
    );
  };

  const filtered = articles.filter(
    (art) =>
      art.title.toLowerCase().includes(searchInput.toLowerCase()) ||
      art.content.toLowerCase().includes(searchInput.toLowerCase())
  );

  return (
    <div>
      <input
        type="text"
        placeholder="Search articles..."
        value={searchInput}
        onChange={(e) => setSearchInput(e.target.value)}
      />
      <p>{filtered.length} articles found</p>

      {filtered.map((art) => (
        <div key={art.id} style={{ marginBottom: "18px" }}>
          <h3>{highlightMatch(art.title)}</h3>
          <p>{highlightMatch(art.content)}</p>
        </div>
      ))}
    </div>
  );
};

export default ArticleSearch;
