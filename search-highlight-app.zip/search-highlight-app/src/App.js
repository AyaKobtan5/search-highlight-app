import React from "react";
import "./App.css";
import ArticleSearch from "./components/Search";

const myArticles = [
  {
    id: 1,
    title: "Grid Template vs Grid Auto in CSS",
    content: "I always get confused between grid-template and grid-auto in CSS Grid. Here's a quick guide to help you understand the difference."
  },
  {
    id: 2,
    title: "Making GitHub Contribution Graph with CSS Grid",
    content: "Step-by-step instructions to recreate GitHub’s contribution graph using CSS Grid."
  }
];

function App() {
  return (
    <div className="App">
      <h1>Search Your Articles</h1>
      <ArticleSearch articles={myArticles} />
    </div>
  );
}

export default App;
